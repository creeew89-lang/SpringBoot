package com.umble.campus.dto;

import com.umble.campus.model.Course;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CourseResponseDTO {
    private Long courseId;
    private String courseName;
    private String code;
    private InstructorDTO instructor;
    private DepartmentDTO department;
    private List<MarkDTO> marks;

public Long getCourseId() {return courseId; }
public void setCourseId(Long courseId){
    this.courseId = courseId; }
    public String getCourseName() {return courseName; }
    public void setCourseName(String courseName){
    this.courseName = courseName; }
    public String getCode() { return code; }
    public void setCode(String code) {
        this.code = code;
    }
}




