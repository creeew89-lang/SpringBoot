package com.umble.campus.controller;

import com.umble.campus.dto.CourseRequestDTO;
import com.umble.campus.dto.CourseResponseDTO;
import com.umble.campus.service.CourseService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/courses")
@RequiredArgsConstructor
public class CourseController {

    private final CourseService courseService;

    @GetMapping
    public List<CourseResponseDTO> getAllCourses() {
        return courseService.findAll();
    }

    @GetMapping("/{id}")
    public CourseResponseDTO getCourse(@PathVariable Long id) {
        return courseService.findById(id);
    }

    @PostMapping("/addFull")
    @ResponseStatus(HttpStatus.CREATED)
    public CourseResponseDTO addFullCourse(@Valid @RequestBody CourseRequestDTO dto) {
        return courseService.createCourseWithRelations(dto);
    }
}