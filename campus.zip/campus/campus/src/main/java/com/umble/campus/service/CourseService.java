package com.umble.campus.service;

import com.umble.campus.dto.CourseRequestDTO;
import com.umble.campus.dto.CourseResponseDTO;
import com.umble.campus.model.Course;
import com.umble.campus.repo.CourseRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CourseService {

    private final CourseRepository courseRepository;

    public CourseResponseDTO createCourseWithRelations(CourseRequestDTO dto) {
        Course course = new Course();
        course.setName(dto.getCourseName());
        course.setCode(dto.getCode());
        Course saved = courseRepository.save(course);
        return mapToDTO(saved);
    }

    public List<CourseResponseDTO> findAll() {
        return courseRepository.findAll()
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public CourseResponseDTO findById(Long id) {
        Course c = courseRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Course not found"));
        return mapToDTO(c);
    }

    private CourseResponseDTO mapToDTO(Course c) {
        CourseResponseDTO dto = new CourseResponseDTO();
        dto.setCourseId(c.getId());
        dto.setCourseName(c.getName());
        return dto;
    }
}