package com.umble.campus.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "marks")
public class Mark {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String studentName;
    private Double score;

    @ManyToOne
    @JoinColumn(name = "course_id")
    private Course course;
}