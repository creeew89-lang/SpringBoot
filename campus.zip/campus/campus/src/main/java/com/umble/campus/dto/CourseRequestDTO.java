package com.umble.campus.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.util.List;

@Data
    public class CourseRequestDTO{
        @NotBlank
        private String courseName;
        private String code;
        private Long instructorId;
        private String instructorName;
        private Long departmentId;
        private String departmentTitle;

    public @NotBlank String getCourseName() {
        return courseName;
    }

    public void setCourseName(@NotBlank String courseName) {
        this.courseName = courseName;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Long getInstructorId() {
        return instructorId;
    }

    public void setInstructorId(Long instructorId) {
        this.instructorId = instructorId;
    }

    public String getInstructorName() {
        return instructorName;
    }

    public void setInstructorName(String instructorName) {
        this.instructorName = instructorName;
    }

    public Long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }

    public String getDepartmentTitle() {
        return departmentTitle;
    }

    public void setDepartmentTitle(String departmentTitle) {
        this.departmentTitle = departmentTitle;
    }

    public @Valid List<MarkDTO> getMarks() {
        return marks;
    }

    public void setMarks(@Valid List<MarkDTO> marks) {
        this.marks = marks;
    }



    @Valid
        private List <MarkDTO> marks;
    }
