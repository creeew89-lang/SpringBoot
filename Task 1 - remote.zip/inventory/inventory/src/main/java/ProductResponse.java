import java.math.BigDecimal;
import java.time.LocalDate;

public class ProductResponse {
    private Long id;
    private String name;
    private String category;
    private BigDecimal price;
    private Integer availableQuantity;
    private boolean active;
    private LocalDate createdDate;
    private LocalDate updatedDate;
}
