package tra.codline.almuiayed.inventory.Exceptions;

public class ResourceNotFoundException extends RuntimeException{
    public ResourceNotFoundException (String msg) {
        super(msg);
    }
}
