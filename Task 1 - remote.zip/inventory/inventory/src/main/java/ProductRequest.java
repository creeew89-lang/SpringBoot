import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

import java.math.BigDecimal;

public class ProductRequest {
    @NotBlank
    @NotBlank
    @DecimalMin("0.01") private BigDecimal price;
    @Min(0) private Integer availableQuantity;
}
