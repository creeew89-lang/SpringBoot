package tra.codline.almuiayed.inventory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NameProductInventoryManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
