package com.umble.campus.service;

import com.umble.campus.model.Instructor;
import com.umble.campus.repo.InstructorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InstructorService {

    @Autowired
    private InstructorRepository instructorRepository;

    public List<Instructor> getAllInstructor() {
        return instructorRepository.findAll();
    }

    public Instructor getInstructorById(Integer id) throws Exception {
        return instructorRepository.findById(id.longValue())
                .orElseThrow(() -> new Exception("Instructor not found"));
    }

    public Instructor saveInstructor(Instructor instructor) {
        return instructorRepository.save(instructor);
    }

    public void deleteInstructor(Integer id) throws Exception {
        Instructor existing = instructorRepository.findById(id.longValue())
                .orElseThrow(() -> new Exception("Instructor not found"));
        instructorRepository.delete(existing);
    }
}