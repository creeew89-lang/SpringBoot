package com.umble.campus.controller;

import com.umble.campus.model.Course;
import com.umble.campus.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
public class CourseController {

    @Autowired
    private CourseService courseService;

    @PostMapping("create")
    public Course createCourse(@RequestBody Course requestObj) {
        return courseService.saveCourse(requestObj);
    }

    @GetMapping("getAll")
    public List<Course> getAllCourse() {
        return courseService.getAllCourse();
    }

    @GetMapping("getById/{id}")
    public Course getCourse(@PathVariable int id) throws Exception {
        return courseService.getCourseById(id);
    }

    @PutMapping("update")
    public Course updateCourse(@RequestBody Course updateObjFromUser) throws Exception {
        return courseService.updateCourse(updateObjFromUser);
    }

    @DeleteMapping("delete/{id}")
    public String deleteCourse(@PathVariable int id) throws Exception {
        courseService.deleteCourse(id);
        return "SUCCESS";
    }
}