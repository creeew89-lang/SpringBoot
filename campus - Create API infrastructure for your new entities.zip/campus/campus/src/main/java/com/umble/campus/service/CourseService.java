package com.umble.campus.service;

import com.umble.campus.model.Course;
import com.umble.campus.repo.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class CourseService {

    @Autowired
    private CourseRepository courseRepository;

    public List<Course> getAllCourse() {
        return courseRepository.findAll();
    }

    public Course getCourseById(Integer id) throws Exception {
        return courseRepository.findById(id.longValue())
                .orElseThrow(() -> new Exception("Course not found"));
    }

    public Course saveCourse(Course course) {
        course.setCreatedDate(new Date());
        course.setActive(Boolean.TRUE);
        return courseRepository.save(course);
    }

    public Course updateCourse(Course course) throws Exception {
        Course existing = courseRepository.findById(course.getId())
                .orElseThrow(() -> new Exception("Course not found"));
        if (Boolean.TRUE.equals(existing.getActive())) {
            course.setUpdatedDate(new Date());
            return courseRepository.save(course);
        }
        throw new Exception("BAD REQUEST");
    }

    public void deleteCourse(Integer id) throws Exception {
        Course existing = courseRepository.findById(id.longValue())
                .orElseThrow(() -> new Exception("Course not found"));
        existing.setUpdatedDate(new Date());
        existing.setActive(Boolean.FALSE);
        courseRepository.save(existing);
    }
}