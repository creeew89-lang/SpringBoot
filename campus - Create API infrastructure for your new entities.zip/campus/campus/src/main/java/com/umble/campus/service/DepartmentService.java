package com.umble.campus.service;

import com.umble.campus.model.Department;
import com.umble.campus.repo.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentService {

    @Autowired
    private DepartmentRepository departmentRepository;

    public List<Department> getAllDepartment() {
        return departmentRepository.findAll();
    }

    public Department getDepartmentById(Integer id) throws Exception {
        return departmentRepository.findById(id.longValue())
                .orElseThrow(() -> new Exception("Department not found"));
    }

    public Department saveDepartment(Department department) {
        return departmentRepository.save(department);
    }

    public void deleteDepartment(Integer id) throws Exception {
        Department existing = departmentRepository.findById(id.longValue())
                .orElseThrow(() -> new Exception("Department not found"));
        departmentRepository.delete(existing);
    }
}