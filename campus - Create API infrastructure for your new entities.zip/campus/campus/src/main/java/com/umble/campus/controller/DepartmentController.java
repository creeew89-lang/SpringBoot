package com.umble.campus.controller;

import com.umble.campus.model.Department;
import com.umble.campus.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;

    @PostMapping("department/create")
    public Department createDepartment(@RequestBody Department department) {
        return departmentService.saveDepartment(department);
    }

    @GetMapping("department/getAll")
    public List<Department> getAllDepartment() {
        return departmentService.getAllDepartment();
    }

    @GetMapping("department/getById/{id}")
    public Department getDepartment(@PathVariable int id) throws Exception {
        return departmentService.getDepartmentById(id);
    }

    @DeleteMapping("department/delete/{id}")
    public String deleteDepartment(@PathVariable int id) throws Exception {
        departmentService.deleteDepartment(id);
        return "SUCCESS";
    }
}