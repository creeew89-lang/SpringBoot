package com.umble.campus.controller;

import com.umble.campus.model.Instructor;
import com.umble.campus.service.InstructorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
public class InstructorController {

    @Autowired
    private InstructorService instructorService;

    @PostMapping("instructor/create")
    public Instructor createInstructor(@RequestBody Instructor instructor) {
        return instructorService.saveInstructor(instructor);
    }

    @GetMapping("instructor/getAll")
    public List<Instructor> getAllInstructor() {
        return instructorService.getAllInstructor();
    }

    @GetMapping("instructor/getById/{id}")
    public Instructor getInstructor(@PathVariable int id) throws Exception {
        return instructorService.getInstructorById(id);
    }

    @DeleteMapping("instructor/delete/{id}")
    public String deleteInstructor(@PathVariable int id) throws Exception {
        instructorService.deleteInstructor(id);
        return "SUCCESS";
    }
}